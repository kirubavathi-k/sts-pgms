package com.thbs.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.thbs.demo.model.Ticket;
import com.thbs.demo.model.*;


public interface TicketRepository  extends JpaRepository<Ticket,Integer>{
	
}
