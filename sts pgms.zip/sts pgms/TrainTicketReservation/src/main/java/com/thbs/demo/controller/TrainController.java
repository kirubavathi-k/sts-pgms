

package com.thbs.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.thbs.demo.model.Passenger;
import com.thbs.demo.model.Train;
import com.thbs.demo.repository.PassengerRepository;
import com.thbs.demo.repository.TrainRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class TrainController {

	@Autowired
	TrainRepository userRepository;
	
	 @PostMapping("/train")
		public ResponseEntity<Train> createTrain(@RequestBody Train user){
		   System.out.println(user.getTrain_no());
		   System.out.println(user.getTrain_name());
		   System.out.println(user.getSource());
		   System.out.println(user.getDestination());
		   
		 try {
			 Train _user= userRepository.save(new Train(0, user.getTrain_no(),user.getTrain_name(),user.getSource(),user.getDestination()));
			 return new ResponseEntity<>(_user,HttpStatus.CREATED);
		 }catch(Exception ex) {
			 return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		 }
	   }
	 
	 @GetMapping("/train")
	 public ResponseEntity<List<Train>> getAllTrain(){
		 try {
			 List<Train> users=new ArrayList<Train>();
			 userRepository.findAll().forEach(users::add);
			 return new ResponseEntity<>(users,HttpStatus.OK);
		 }catch(Exception ex) {
			 return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		 }
	 }
	 
	
	 @GetMapping("/train/{id}")
		public ResponseEntity<Train> getTrainById(@PathVariable("id") int id){
			Optional<Train> userData = userRepository.findById(id);
			
			if(userData.isPresent()) {
				return new ResponseEntity<>(userData.get(),HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}		
		}
		
		@PutMapping("/train/{id}")
		public ResponseEntity<Train> updateTrain(@PathVariable("id") int id,@RequestBody Train user){
	        Optional<Train> userData = userRepository.findById(id);
			
			if(userData.isPresent()) {
				Train _user = userData.get();
				_user.setTrain_no(user.getTrain_no());
				_user.setTrain_name(user.getTrain_name());
				_user.setSource(user.getSource());
				_user.setDestination(user.getDestination());
				
				return new ResponseEntity<>(userRepository.save(_user),HttpStatus.OK);
			}else {
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}	
		}

	@DeleteMapping("/train/{id}")
		public ResponseEntity<HttpStatus> deleteTrain(@PathVariable("id") int id){
			try {
				userRepository.deleteById(id);
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}catch(Exception ex) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
}
		

		   

	


