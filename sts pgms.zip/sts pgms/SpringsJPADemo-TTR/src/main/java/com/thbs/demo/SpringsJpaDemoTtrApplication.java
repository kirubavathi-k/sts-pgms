package com.thbs.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringsJpaDemoTtrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringsJpaDemoTtrApplication.class, args);
	}

}
