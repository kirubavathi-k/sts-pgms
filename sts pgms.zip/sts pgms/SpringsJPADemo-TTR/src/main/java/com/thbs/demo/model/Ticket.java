package com.thbs.demo.model;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Ticket")
public class Ticket {

	 @Id
	 @GeneratedValue(strategy=GenerationType.AUTO)
	private int counter;
	 @Column(name="from")
	private String from;
	 @Column(name="to")
	private String to;
	 @Column(name="date")
	private String date;
	
	Ticket(){
	}

	public Ticket(int counter, String from, String to, String date) {
		super();
		this.counter = counter;
		this.from = from;
		this.to = to;
		this.date = date;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Ticket [counter=" + counter + ", from=" + from + ", to=" + to + ", date=" + date + "]";
	}
	
	}

