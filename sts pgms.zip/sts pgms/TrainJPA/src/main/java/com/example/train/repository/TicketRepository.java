package com.example.train.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.train.model.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Integer>{

}
