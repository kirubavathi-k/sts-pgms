package com.example.train.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.train.model.Passanger;

public interface PassangerRepository extends JpaRepository<Passanger, Integer> {

}
