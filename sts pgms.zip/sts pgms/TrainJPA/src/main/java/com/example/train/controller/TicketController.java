package com.example.train.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.train.model.Ticket;
import com.example.train.repository.TicketRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class TicketController {

	@Autowired
	TicketRepository ticketRepository;
	
	@PostMapping("/ticket")
	public ResponseEntity<Ticket> createUser(@RequestBody Ticket user){		
	try {
		Ticket _user	= ticketRepository.save(new Ticket(user.getT_number(),user.getTravel_date(),user.getFare()));
	    return new ResponseEntity<>(_user,HttpStatus.CREATED);
	}catch(Exception ex) {		
		return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	}
	
	@GetMapping("/ticket")
	public ResponseEntity<List<Ticket>> getAllUsers(){
		try {
			List<Ticket> users = new ArrayList<Ticket>();
			ticketRepository.findAll().forEach(users::add);
			return new ResponseEntity<>(users,HttpStatus.OK);
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping("/ticket/{id}")
	public ResponseEntity<Ticket> getUserById(@PathVariable("id") int id){
		Optional<Ticket> userData = ticketRepository.findById(id);
		
		if(userData.isPresent()) {
			return new ResponseEntity<>(userData.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}		
	}
	
	@PutMapping("/ticket/{id}")
	public ResponseEntity<Ticket> updateUser(@PathVariable("id") int id,@RequestBody Ticket user){
        Optional<Ticket> userData = ticketRepository.findById(id);
		
		if(userData.isPresent()) {
			Ticket _user = userData.get();
			_user.setT_number(user.getT_number());
			_user.setTravel_date(user.getTravel_date());
			_user.setFare(user.getFare());

			return new ResponseEntity<>(ticketRepository.save(_user),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}	
	}
	
	@DeleteMapping("/ticket/{id}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") int id){
		try {
			ticketRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	
	
	
	
	
	
	
}
