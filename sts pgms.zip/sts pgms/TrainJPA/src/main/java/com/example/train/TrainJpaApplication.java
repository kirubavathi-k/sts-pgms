package com.example.train;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainJpaApplication.class, args);
	}

}
