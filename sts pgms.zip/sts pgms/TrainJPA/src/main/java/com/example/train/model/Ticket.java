package com.example.train.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="ticket")
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
    
    @Column(name = "T_number")
	private int T_number;
    
    @Column(name = "travel_date")
	private String travel_date;
    
    @Column(name = "fare")
	private int fare;
    
   Ticket(){
	   
   }




public Ticket(int t_number, String travel_date, int fare) {
		super();
		T_number = t_number;
		this.travel_date = travel_date;
		this.fare = fare;
	}






public int getId() {
		return id;
	}






	public void setId(int id) {
		this.id = id;
	}






	public int getT_number() {
		return T_number;
	}






	public void setT_number(int t_number) {
		T_number = t_number;
	}






	public String getTravel_date() {
		return travel_date;
	}






	public void setTravel_date(String travel_date) {
		this.travel_date = travel_date;
	}






	public int getFare() {
		return fare;
	}






	public void setFare(int fare) {
		this.fare = fare;
	}






@Override
public String toString() {
	return "User [id=" +id+",T_number="+T_number+",travel_date="+travel_date+",+fare="+fare+"]";
	}
    
}