package com.example.train.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.train.model.Passanger;
import com.example.train.repository.PassangerRepository;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api")
public class PassangerController {
	
	@Autowired
	PassangerRepository passangerRepository;

	@PostMapping("/passangers")
	public ResponseEntity<Passanger> createPassanger(@RequestBody Passanger passanger){
		try {
			Passanger _passanger = passangerRepository.save(new Passanger(passanger.getName(),passanger.getAge(),passanger.getGender()));
		    return new ResponseEntity<>(_passanger,HttpStatus.CREATED);
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@GetMapping("/passangers")
	public ResponseEntity<List<Passanger>> getAllPassanger(){
		try {
			List<Passanger> passangers = new ArrayList<Passanger>();
			passangerRepository.findAll().forEach(passangers::add);
			return new ResponseEntity<>(passangers,HttpStatus.OK);
		}catch(Exception ex) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	@GetMapping("/passangers/{id}")
	public ResponseEntity<Passanger> getPassangerById(@PathVariable("id") int id){
		Optional<Passanger> passangerData = passangerRepository.findById(id);
		
		if(passangerData.isPresent()) {
			return new ResponseEntity<>(passangerData.get(),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}		
	}
	
	@PutMapping("/passangers/{id}")
	public ResponseEntity<Passanger> updatePassanger(@PathVariable("id") int id,@RequestBody Passanger passanger){
        Optional<Passanger> passangerData = passangerRepository.findById(id);
		
		if(passangerData.isPresent()) {
			Passanger _passanger = passangerData.get();
			_passanger.setName(passanger.getName());
			_passanger.setAge(passanger.getAge());
			_passanger.setGender(passanger.getGender());
			return new ResponseEntity<>(passangerRepository.save(_passanger),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}	
	}
	
	@DeleteMapping("/passangers/{id}")
	public ResponseEntity<HttpStatus> deletePassanger(@PathVariable("id") int id){
		try {
			passangerRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}catch(Exception ex) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
